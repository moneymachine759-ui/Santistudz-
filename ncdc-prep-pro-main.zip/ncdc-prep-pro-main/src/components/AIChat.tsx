import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Bot, User } from "lucide-react";

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

export function AIChat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I\'m your AI assistant for the Ugandan Lower Secondary Competency-Based Curriculum. I can help you with questions about any subject from Senior 1 to Senior 4. What would you like to learn about today?',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputMessage,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage("");
    setIsLoading(true);

    // Simulate AI response (replace with actual AI integration)
    setTimeout(() => {
      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        content: getAIResponse(inputMessage),
        sender: 'ai',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsLoading(false);
    }, 1500);
  };

  const getAIResponse = (question: string): string => {
    // This is a placeholder function. In a real app, you'd integrate with an AI service
    const lowerQuestion = question.toLowerCase();
    
    if (lowerQuestion.includes('biology') || lowerQuestion.includes('cell')) {
      return "In Biology, cells are the basic units of life. In Senior 1, you'll learn about cell structure including the cell membrane, cytoplasm, and nucleus. For plant cells, you'll also study the cell wall and chloroplasts. Would you like me to explain any specific part of cell structure?";
    } else if (lowerQuestion.includes('chemistry') || lowerQuestion.includes('periodic')) {
      return "Chemistry in the NCDC curriculum starts with basic concepts in Senior 1. The periodic table organizes elements by atomic number. Elements in the same group have similar properties. Would you like to know about specific elements or chemical reactions?";
    } else if (lowerQuestion.includes('physics') || lowerQuestion.includes('force')) {
      return "Physics concepts build from Senior 1 to Senior 4. Forces are pushes or pulls that can change an object's motion. Newton's laws explain how forces work. The first law states that objects at rest stay at rest unless acted upon by a force. What specific physics topic interests you?";
    } else if (lowerQuestion.includes('math') || lowerQuestion.includes('algebra')) {
      return "Mathematics in the competency-based curriculum progresses from basic number systems in Senior 1 to advanced topics like calculus in Senior 4. Algebra involves using letters to represent unknown numbers. What specific math concept would you like help with?";
    } else {
      return "I can help you with any subject in the Ugandan Lower Secondary curriculum including Biology, Chemistry, Physics, Mathematics, ICT, Technology & Design, Art & Design, Religious Education, and Physical Education. Please ask me about any specific topic, and I'll provide detailed explanations aligned with the NCDC syllabus.";
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="flex flex-col h-screen pb-20">
      <div className="p-4 border-b">
        <h1 className="text-2xl font-bold text-center" style={{ color: "hsl(var(--ai))" }}>
          AI Learning Assistant
        </h1>
        <p className="text-center text-muted-foreground mt-2">
          Ask questions about the Ugandan Lower Secondary Curriculum
        </p>
      </div>

      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[80%] ${message.sender === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                  message.sender === 'user' ? 'bg-primary' : 'bg-secondary'
                }`}>
                  {message.sender === 'user' ? (
                    <User size={16} className="text-primary-foreground" />
                  ) : (
                    <Bot size={16} className="text-secondary-foreground" />
                  )}
                </div>
                <Card className={message.sender === 'user' ? 'bg-primary text-primary-foreground' : ''}>
                  <CardContent className="p-3">
                    <p className="text-sm">{message.content}</p>
                    <span className="text-xs opacity-70 mt-1 block">
                      {message.timestamp.toLocaleTimeString()}
                    </span>
                  </CardContent>
                </Card>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-3 justify-start">
              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                <Bot size={16} className="text-secondary-foreground" />
              </div>
              <Card>
                <CardContent className="p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-current rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="p-4 border-t bg-background">
        <div className="flex gap-2">
          <Input
            placeholder="Ask about any curriculum topic..."
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            disabled={isLoading}
          />
          <Button 
            onClick={handleSendMessage} 
            disabled={!inputMessage.trim() || isLoading}
            size="icon"
          >
            <Send size={20} />
          </Button>
        </div>
      </div>
    </div>
  );
}