import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { Search, ChevronDown, ChevronRight } from "lucide-react";
import { useState } from "react";

interface Topic {
  title: string;
  content: string;
  outcomes?: string[];
}

interface SubjectTabsProps {
  subjectTitle: string;
  color: string;
  topics: {
    S1: Topic[];
    S2: Topic[];
    S3: Topic[];
    S4: Topic[];
  };
}

export function SubjectTabs({ subjectTitle, color, topics }: SubjectTabsProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [openTopics, setOpenTopics] = useState<Set<string>>(new Set());

  const filterTopics = (topicList: Topic[]) => {
    if (!searchTerm) return topicList;
    return topicList.filter(topic =>
      topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      topic.content.toLowerCase().includes(searchTerm.toLowerCase())
    );
  };

  const toggleTopic = (topicId: string) => {
    const newOpenTopics = new Set(openTopics);
    if (newOpenTopics.has(topicId)) {
      newOpenTopics.delete(topicId);
    } else {
      newOpenTopics.add(topicId);
    }
    setOpenTopics(newOpenTopics);
  };

  const renderTopicCard = (topic: Topic, index: number, level: string) => {
    const topicId = `${level}-${index}`;
    const isOpen = openTopics.has(topicId);
    
    return (
      <Card key={index} className="mb-4 glass-effect">
        <Collapsible>
          <CollapsibleTrigger 
            className="w-full p-0"
            onClick={() => toggleTopic(topicId)}
          >
            <CardHeader className="hover:bg-card/50 transition-colors">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg text-left" style={{ color: `hsl(var(--${color}))` }}>
                  {topic.title}
                </CardTitle>
                <div className="flex-shrink-0 ml-4">
                  {isOpen ? (
                    <ChevronDown className="h-5 w-5 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  )}
                </div>
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <CardContent className="pt-0">
              {topic.outcomes && (
                <div className="text-sm text-muted-foreground mb-4">
                  <strong>Learning Outcomes:</strong>
                  <ul className="mt-2 space-y-1">
                    {topic.outcomes.map((outcome, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <span>•</span>
                        <span>{outcome}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
              <div className="prose prose-sm max-w-none">
                {topic.content.split('\n').map((paragraph, i) => (
                  <p key={i} className="mb-2">{paragraph}</p>
                ))}
              </div>
            </CardContent>
          </CollapsibleContent>
        </Collapsible>
      </Card>
    );
  };

  return (
    <div className="p-4 pb-20">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-4" style={{ color: `hsl(var(--${color}))` }}>
          {subjectTitle}
        </h1>
        
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
          <Input
            placeholder={`Search ${subjectTitle} topics...`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <Tabs defaultValue="S1" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="S1">Senior 1</TabsTrigger>
          <TabsTrigger value="S2">Senior 2</TabsTrigger>
          <TabsTrigger value="S3">Senior 3</TabsTrigger>
          <TabsTrigger value="S4">Senior 4</TabsTrigger>
        </TabsList>

        <TabsContent value="S1" className="mt-6">
          <div className="space-y-4">
            {filterTopics(topics.S1).map((topic, index) => renderTopicCard(topic, index, "S1"))}
          </div>
        </TabsContent>

        <TabsContent value="S2" className="mt-6">
          <div className="space-y-4">
            {filterTopics(topics.S2).map((topic, index) => renderTopicCard(topic, index, "S2"))}
          </div>
        </TabsContent>

        <TabsContent value="S3" className="mt-6">
          <div className="space-y-4">
            {filterTopics(topics.S3).map((topic, index) => renderTopicCard(topic, index, "S3"))}
          </div>
        </TabsContent>

        <TabsContent value="S4" className="mt-6">
          <div className="space-y-4">
            {filterTopics(topics.S4).map((topic, index) => renderTopicCard(topic, index, "S4"))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}