import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface SubjectCardProps {
  title: string;
  icon: LucideIcon;
  color: string;
  onClick: () => void;
}

export function SubjectCard({ title, icon: Icon, color, onClick }: SubjectCardProps) {
  return (
    <Card 
      className="cursor-pointer transition-all duration-300 hover:scale-105 hover:-translate-y-1 card-effect group relative overflow-hidden"
      onClick={onClick}
    >
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-br from-primary/5 to-accent/5" />
      <CardContent className="p-6 text-center relative z-10">
        <div 
          className="w-20 h-20 mx-auto mb-4 rounded-2xl flex items-center justify-center shadow-lg transition-all duration-300 group-hover:shadow-xl group-hover:scale-110"
          style={{ 
            backgroundColor: `hsl(var(--${color}))`,
            boxShadow: `0 8px 24px hsl(var(--${color}) / 0.3)`
          }}
        >
          <Icon size={36} className="text-white" />
        </div>
        <h3 className="font-semibold text-lg text-foreground group-hover:text-primary transition-colors duration-300">
          {title}
        </h3>
      </CardContent>
    </Card>
  );
}