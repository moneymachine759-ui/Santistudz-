import { useState } from "react";
import { Navigation } from "@/components/Navigation";
import { SubjectCard } from "@/components/SubjectCard";
import { SubjectTabs } from "@/components/SubjectTabs";
import { AIChat } from "@/components/AIChat";
import { subjects } from "@/data/subjects";
import { Input } from "@/components/ui/input";
import { Search, Sparkles } from "lucide-react";
import heroImage from "@/assets/hero-education.jpg";
import studySpace from "@/assets/study-space.jpg";
import classroomBg from "@/assets/classroom-bg.jpg";

const Index = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [selectedSubject, setSelectedSubject] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  const handleSubjectClick = (subject) => {
    setSelectedSubject(subject);
    setActiveTab('subjects');
  };

  const handleBackToHome = () => {
    setSelectedSubject(null);
    setActiveTab('home');
  };

  const filteredSubjects = subjects.filter(subject =>
    subject.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderHome = () => (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-lg sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center gap-4">
              <div className="text-2xl font-bold text-primary">
                Uganda<span className="text-secondary">Learn</span>
              </div>
            </div>
            <nav className="hidden md:flex gap-8">
              <a href="#" className="font-medium text-foreground hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">Home</a>
              <a href="#" className="font-medium text-foreground hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">Subjects</a>
              <a href="#" className="font-medium text-foreground hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">Resources</a>
              <a href="#" className="font-medium text-foreground hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">Exams</a>
              <a href="#" className="font-medium text-foreground hover:text-primary transition-colors relative after:absolute after:bottom-0 after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">About</a>
            </nav>
            <div className="flex gap-4">
              <button className="btn-modern btn-primary-modern">Get Started</button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="flex flex-col lg:flex-row items-center gap-12">
            <div className="lg:w-1/2 text-center lg:text-left">
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight mb-6">
                All Your <span className="text-primary">Lower Secondary</span> Notes in One Place
              </h1>
              <p className="text-xl text-muted-foreground mb-8 max-w-xl">
                Access comprehensive curriculum notes, study guides, and exam resources for all subjects in Uganda's Lower Secondary Education.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <button className="btn-modern btn-primary-modern">Explore Subjects</button>
                <button className="btn-modern btn-outline-modern">Watch Video Tour</button>
              </div>
            </div>
            <div className="lg:w-1/2 flex justify-center">
              <img 
                src={heroImage}
                alt="Ugandan Students Learning" 
                className="max-w-full h-auto rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Subjects Section */}
      <section className="py-20 bg-white rounded-t-[30px] -mt-8 shadow-xl">
        <div className="max-w-6xl mx-auto px-6">
          <div className="section-title">
            <h2>All Subjects Covered</h2>
            <p>Access complete notes, past papers, and study resources for every subject in the Ugandan Lower Secondary Curriculum</p>
          </div>
          
          {/* Search */}
          <div className="max-w-2xl mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
              <Input
                placeholder="Search subjects and topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 h-14 text-lg border-2 focus:border-primary"
              />
            </div>
          </div>

          {/* Subjects Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {filteredSubjects.map((subject) => {
              const IconComponent = subject.icon;
              return (
                <div key={subject.id} className="card-modern border group cursor-pointer" onClick={() => handleSubjectClick(subject)}>
                  <div className="p-6 text-center bg-gradient-to-br from-primary to-accent text-white">
                    <IconComponent size={48} className="mx-auto mb-4" />
                    <h3 className="text-xl font-semibold">{subject.title}</h3>
                  </div>
                  <div className="p-6">
                    <ul className="space-y-3">
                      <li className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                        Senior 1 - 4 Content
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                        NCDC Curriculum Aligned
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                        Study Guides & Notes
                      </li>
                      <li className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-primary rounded-full mr-3"></div>
                        Practice Questions
                      </li>
                    </ul>
                  </div>
                  <div className="px-6 py-4 bg-gray-50 border-t group-hover:bg-primary group-hover:text-white transition-colors duration-300">
                    <div className="text-center font-semibold">View Notes</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto px-6">
          <div className="section-title">
            <h2>Why Students Love Our Platform</h2>
            <p>Designed specifically for Ugandan students to excel in their studies</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center p-8 card-modern">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-6">
                <Sparkles className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Comprehensive Notes</h3>
              <p className="text-muted-foreground">Detailed, curriculum-aligned notes for every subject and topic in the Ugandan syllabus.</p>
            </div>
            
            <div className="text-center p-8 card-modern">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-6">
                <Search className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-semibold mb-4">Mobile Friendly</h3>
              <p className="text-muted-foreground">Access all resources on any device, even with limited internet connectivity.</p>
            </div>
            
            <div className="text-center p-8 card-modern">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="text-white text-3xl">📄</div>
              </div>
              <h3 className="text-xl font-semibold mb-4">Past Papers</h3>
              <p className="text-muted-foreground">Thousands of past exam papers with marking guides to help you prepare.</p>
            </div>
            
            <div className="text-center p-8 card-modern">
              <div className="w-20 h-20 bg-gradient-to-br from-primary to-accent rounded-full flex items-center justify-center mx-auto mb-6">
                <div className="text-white text-3xl">⬇️</div>
              </div>
              <h3 className="text-xl font-semibold mb-4">Downloadable Content</h3>
              <p className="text-muted-foreground">Download notes and resources for offline studying anytime, anywhere.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-dark text-white py-16">
        <div className="max-w-6xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-semibold mb-6 relative pb-2 after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-primary">
                UgandaLearn
              </h3>
              <p className="text-gray-300">Your comprehensive resource for Ugandan Lower Secondary education materials, notes, and exam preparation.</p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-6 relative pb-2 after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-primary">
                Quick Links
              </h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Home</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Subjects</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Resources</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Past Papers</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Study Guides</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-6 relative pb-2 after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-primary">
                Subjects
              </h3>
              <ul className="space-y-3">
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Mathematics</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">English</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Science</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">Social Studies</a></li>
                <li><a href="#" className="text-gray-300 hover:text-primary transition-colors">All Subjects</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-6 relative pb-2 after:absolute after:bottom-0 after:left-0 after:w-12 after:h-0.5 after:bg-primary">
                Contact Us
              </h3>
              <ul className="space-y-3">
                <li className="text-gray-300">✉️ support@ugandalearn.com</li>
                <li className="text-gray-300">📞 +256 700 123 456</li>
                <li className="text-gray-300">📍 Kampala, Uganda</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-600 pt-8 text-center">
            <p className="text-gray-400">&copy; 2023 UgandaLearn. All rights reserved. Designed for Ugandan Lower Secondary Students.</p>
          </div>
        </div>
      </footer>
    </div>
  );

  const renderSubjects = () => {
    if (selectedSubject) {
      return (
        <div>
          <div className="p-4 border-b bg-card">
            <button
              onClick={handleBackToHome}
              className="text-primary hover:underline mb-2"
            >
              ← Back to Subjects
            </button>
          </div>
          <SubjectTabs
            subjectTitle={selectedSubject.title}
            color={selectedSubject.color}
            topics={selectedSubject.topics}
          />
        </div>
      );
    }

    return renderHome();
  };

  const renderSearchAll = () => (
    <div className="p-6 pb-20">
      <h1 className="text-2xl font-bold mb-6">Search All Subjects</h1>
      <div className="mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
          <Input
            placeholder="Search across all subjects and topics..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>
      
      {searchTerm && (
        <div className="space-y-4">
          {subjects.map((subject) => {
            const matchingTopics = Object.entries(subject.topics).flatMap(([level, topics]) =>
              topics.filter(topic =>
                topic.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                topic.content.toLowerCase().includes(searchTerm.toLowerCase())
              ).map(topic => ({ ...topic, level, subject: subject.title, color: subject.color }))
            );

            if (matchingTopics.length === 0) return null;

            return (
              <div key={subject.id} className="border rounded-lg p-4">
                <h3 className="font-semibold text-lg mb-3" style={{ color: `hsl(var(--${subject.color}))` }}>
                  {subject.title}
                </h3>
                <div className="space-y-2">
                  {matchingTopics.map((topic, idx) => (
                    <div key={idx} className="border-l-2 pl-3" style={{ borderColor: `hsl(var(--${topic.color}))` }}>
                      <h4 className="font-medium">{topic.level}: {topic.title}</h4>
                      <p className="text-sm text-muted-foreground line-clamp-2">
                        {topic.content.substring(0, 150)}...
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );


  return (
    <div className="min-h-screen bg-background relative">
      {/* Study Environment Background */}
      <div 
        className="fixed inset-0 opacity-5 bg-cover bg-center pointer-events-none"
        style={{ backgroundImage: `url(${studySpace})` }}
      />
      
      <div className="relative z-10">
        {activeTab === 'home' && renderHome()}
        {activeTab === 'subjects' && renderSubjects()}
        {activeTab === 'search' && renderSearchAll()}
        {activeTab === 'ai-chat' && <AIChat />}
      </div>
      
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default Index;
