import { 
  Microscope, 
  TestTube, 
  Zap, 
  Calculator, 
  Monitor, 
  Wrench, 
  Palette, 
  Church, 
  Activity,
  Brain,
  BookOpen,
  Globe,
  Users,
  MessageCircle,
  Wheat
} from "lucide-react";

export const subjects = [
  {
    id: 'biology',
    title: 'Biology',
    icon: Microscope,
    color: 'biology',
    topics: {
      S1: [
        {
          title: "Introduction to Biology",
          outcomes: [
            "Understand biology as a study of life and that all living organisms experience common life processes",
            "Recognize that biology is the study of living things",
            "Identify the seven life processes common to all organisms",
            "Give examples of how biology applies to daily life"
          ],
          content: "Biology is defined as the study of life. According to cell theory, all living things are composed of one or more cells, that the cell is the basic unit of life, and every organism carries out life processes.\n\nThe seven life processes (MRS GREN) are:\n• Movement - ability to change position\n• Respiration - release of energy from food\n• Sensitivity - response to stimuli\n• Growth - increase in size and mass\n• Reproduction - production of offspring\n• Excretion - removal of waste products\n• Nutrition - obtaining and using food\n\nPlants typically make their own food (autotrophic) via photosynthesis in chloroplasts, whereas animals obtain nutrients heterotrophically. Plants exhibit sensitivity through tropisms (growth responses) and rigid support from cell walls, whereas animals move via muscles and nervous coordination."
        },
        {
          title: "Cells",
          outcomes: [
            "Appreciate the cell as the basic unit of living organisms",
            "Understand the structure and functions of cell components",
            "Distinguish between plant and animal cells",
            "Understand that similar cells form tissues and organs"
          ],
          content: "Cells are the 'building blocks of life' – every organism (plant or animal) is made of cells. Key cell parts include:\n• Nucleus - stores DNA and controls cell activities\n• Cell membrane - controls material exchange\n• Cytoplasm - jelly-like substance where reactions occur\n• Mitochondria - produce energy for the cell\n• Ribosomes - make proteins\n• Endoplasmic reticulum - transport system\n• Golgi apparatus - packages and modifies materials\n\nPlant cells have additional structures:\n• Cell wall - rigid structure for support\n• Chloroplasts - contain chlorophyll for photosynthesis\n• Large central vacuole - stores water and maintains shape\n\nAnimal cells have:\n• Centrioles - help with cell division\n• Lysosomes - digest waste materials\n\nMulticellular life has hierarchical organization: cells → tissues → organs → organ systems."
        },
        {
          title: "Classification",
          outcomes: [
            "Understand that classification is the sorting of living things based on similarities",
            "State why classification is needed",
            "List levels of classification",
            "Learn key features of each kingdom"
          ],
          content: "Classification is needed to organize biodiversity and study evolutionary relationships. The hierarchical levels of classification are:\nDomain → Kingdom → Phylum → Class → Order → Family → Genus → Species\n\nThe five kingdoms of life:\n\n1. Kingdom Monera\n• Prokaryotes like bacteria\n• No nucleus\n• Example: E. coli\n\n2. Kingdom Protista\n• Mostly unicellular eukaryotes\n• Example: Amoeba\n\n3. Kingdom Fungi\n• Saprophytic eukaryotes with chitin cell walls\n• Examples: mushrooms, yeasts\n\n4. Kingdom Plantae\n• Multicellular autotrophs with cellulose walls\n• Photosynthetic\n\n5. Kingdom Animalia\n• Multicellular heterotrophs\n• Motile organisms\n\nEach level groups organisms by shared traits. Modern taxonomy often uses DNA analysis."
        },
        {
          title: "Insects",
          outcomes: [
            "Understand characteristics of insects and relate structures to their functions",
            "Describe insect features and body plan",
            "Explain how each part functions",
            "List examples of insect metamorphosis"
          ],
          content: "Insects have a distinct three-part body plan:\n\n1. Head - bears antennae (sensing), compound eyes (vision), and mouthparts (feeding)\n2. Thorax - with three pairs of legs and usually two pairs of wings (locomotion)\n3. Abdomen - containing digestive and reproductive organs\n\nInsects show metamorphosis - transformation during life cycle:\n• Complete metamorphosis: egg → larva → pupa → adult (e.g., butterfly)\n• Incomplete metamorphosis: egg → nymph → adult (e.g., grasshopper)\n\nInsects play important ecological roles:\nBeneficial:\n• Pollination (bees, butterflies)\n• Decomposition (flies)\n• Pest control (ladybirds eat aphids)\n\nHarmful:\n• Crop pests (locusts)\n• Disease vectors (mosquitoes)\n\nInsects are the largest group of animals and show remarkable adaptations - grasshopper's powerful hind legs for jumping, butterfly's proboscis for nectar feeding."
        },
        {
          title: "Flowering Plants",
          outcomes: [
            "Understand that different parts of flowering plants carry out different functions",
            "Identify parts of a dicot plant and state their roles",
            "Distinguish monocotyledonous vs dicotyledonous plants",
            "Classify leaf shapes and fruit types"
          ],
          content: "Flowering plants (angiosperms) have specialized parts for different functions:\n\n• Root - absorption of water and nutrients, anchorage\n• Stem - support, transport of materials (xylem and phloem)\n• Leaves - photosynthesis, transpiration\n• Flower - sexual reproduction\n• Fruit - protection and dispersal of seeds\n\nFlower parts:\n• Sepals - protect the flower bud\n• Petals - attract pollinators\n• Stamens - male parts (anther produces pollen)\n• Carpels - female parts (stigma, style, ovary)\n\nPlant modifications:\n• Stems: tubers (potato)\n• Leaves: tendrils (pea)\n• Roots: storage organs (cassava)\n\nMonocots vs Dicots:\n• Monocots: one cotyledon, parallel leaf veins (e.g., maize)\n• Dicots: two cotyledons, network leaf veins (e.g., bean)\n\nPollination and fertilization lead to seed and fruit formation."
        }
      ],
      S2: [
        {
          title: "Physical and Chemical Properties of Soil",
          outcomes: [
            "Know that different soil types are made of different components",
            "Identify types of soil and their characteristics",
            "Determine soil composition and measure properties",
            "Understand the role of air and water in soil fertility"
          ],
          content: "Soil is a mixture of mineral particles and organic material (humus) in different proportions. The main soil types are:\n\n• Sandy soil - large particles, drains quickly, low water retention\n• Clay soil - fine particles, retains water, poor drainage\n• Loam soil - mixture of sand, silt, and clay; ideal for farming\n\nSoil components:\n• Mineral particles (sand, silt, clay)\n• Organic matter (humus from decomposed plants/animals)\n• Air spaces (for root respiration)\n• Water (dissolves nutrients)\n\nSoil properties:\n• Texture - determined by particle size\n• pH - affects nutrient availability (6.0-7.0 is ideal)\n• Water retention - clay holds more water than sand\n• Capillarity - water movement through soil\n\nSoil provides nutrients and a medium for plant growth. Understanding soil composition is crucial for successful agriculture."
        },
        {
          title: "Soil Erosion and Conservation",
          outcomes: [
            "Know how and why soil fertility should be maintained",
            "Recognize fertile soil features",
            "Explain processes of soil erosion",
            "Describe conservation methods and understand the nitrogen cycle"
          ],
          content: "Soil erosion removes topsoil, diminishing fertility. It's caused by:\n• Rain splash and surface runoff\n• Wind action\n• Poor farming practices\n• Deforestation\n\nEffects of erosion:\n• Loss of fertile topsoil\n• Reduced crop yields\n• Silting of water bodies\n• Loss of biodiversity\n\nConservation methods:\n• Terracing (as seen in Kigezi, Uganda)\n• Contour plowing\n• Tree planting and shelterbelts\n• Mulching\n• Crop rotation\n• Cover crops\n\nThe Nitrogen Cycle:\n• Nitrogen fixation by bacteria\n• Plants absorb nitrogen compounds\n• Animals consume plants\n• Decomposition returns nitrogen to soil\n• Bacteria convert nitrogen back to atmospheric form\n\nMicroorganisms play crucial roles in maintaining soil fertility through decomposition and nitrogen fixation."
        },
        {
          title: "Nutrition - Nutrients and Dietary Needs",
          outcomes: [
            "Understand that organisms have different nutritional requirements",
            "Define nutrition and list six food nutrients",
            "Perform simple food tests",
            "Calculate Body Mass Index (BMI)"
          ],
          content: "Nutrition is the process by which organisms obtain and use food for energy, growth, and maintenance.\n\nSix classes of nutrients:\n1. Carbohydrates - energy source (bread, rice, potatoes)\n2. Proteins - growth and repair (meat, beans, eggs)\n3. Fats - energy storage and insulation (oil, butter)\n4. Vitamins - regulate body processes (fruits, vegetables)\n5. Minerals - body functions (calcium for bones, iron for blood)\n6. Water - transport and chemical reactions\n\nFood tests:\n• Starch - iodine solution turns blue-black\n• Protein - Biuret test turns violet\n• Glucose - Benedict's test turns orange-red\n• Fats - emulsion test with ethanol\n\nBalanced diet varies with:\n• Age (children need more protein for growth)\n• Activity level (athletes need more energy)\n• Health conditions\n\nBMI = weight (kg) ÷ height² (m²)\n• Underweight: <18.5\n• Normal: 18.5-24.9\n• Overweight: 25-29.9\n• Obese: ≥30"
        },
        {
          title: "Nutrition in Green Plants (Photosynthesis)",
          outcomes: [
            "Understand that plants are autotrophic",
            "Explain the photosynthesis equation",
            "Perform experiments showing photosynthesis factors",
            "Describe leaf adaptations"
          ],
          content: "Plants are autotrophic - they synthesize their own food through photosynthesis.\n\nPhotosynthesis equation:\n6CO₂ + 6H₂O + light energy → C₆H₁₂O₆ + 6O₂ + H₂O\n(Carbon dioxide + Water + Light → Glucose + Oxygen + Water)\n\nFactors affecting photosynthesis:\n• Light intensity - more light increases rate\n• Carbon dioxide concentration - needed as raw material\n• Temperature - affects enzyme activity\n• Chlorophyll - essential for capturing light\n\nLeaf adaptations for photosynthesis:\n• Broad surface area - maximizes light capture\n• Thin structure - allows gas diffusion\n• Chloroplasts in palisade layer - positioned for light\n• Stomata - allow gas exchange\n• Vascular bundles - transport materials\n\nPhotosynthesis occurs in chloroplasts and produces glucose (food) and oxygen. This process is the basis of all food chains as plants are primary producers.\n\nExperimental evidence:\n• Variegated leaf experiment shows chlorophyll necessity\n• Oxygen bubble production shows light requirement"
        },
        {
          title: "Nutrition in Mammals (Digestion)",
          outcomes: [
            "Know that animals are heterotrophic",
            "Describe how enzymes catalyze digestion",
            "Identify tooth types and relate to feeding",
            "Outline the human digestive system"
          ],
          content: "Animals are heterotrophic - they obtain nutrients from existing plant or animal sources.\n\nDigestive enzymes:\n• Amylase - breaks down starch to maltose (saliva, pancreas)\n• Protease - breaks down proteins to amino acids (stomach, pancreas)\n• Lipase - breaks down fats to fatty acids and glycerol (pancreas)\n\nEnzyme activity affected by:\n• pH - pepsin works in acid (stomach), trypsin in alkali (intestine)\n• Temperature - higher temperature increases rate until denaturation\n\nHuman dentition (heterodont):\n• Incisors - cutting and biting\n• Canines - tearing\n• Premolars and molars - grinding and chewing\n\nDigestive system journey:\n1. Mouth - mechanical breakdown, saliva starts starch digestion\n2. Esophagus - transport via peristalsis\n3. Stomach - acid and pepsin digest proteins\n4. Small intestine - complete digestion, absorption via villi\n5. Large intestine - water absorption, waste formation\n\nAbsorption occurs mainly in the small intestine through villi which increase surface area. Nutrients enter blood and are transported to cells (assimilation).\n\nDental hygiene prevents decay - brushing, fluoride, regular checkups."
        }
      ],
      S3: [
        {
          title: "Gaseous Exchange (Respiration)",
          outcomes: [
            "Know the functions of gas exchange surfaces in different organisms",
            "Explain why large organisms need respiratory organs",
            "Describe the structure of the human respiratory system",
            "Understand damage from smoking and pollution"
          ],
          content: "Large organisms need specialized respiratory systems because they have high surface-area-to-volume ratios, making simple diffusion insufficient.\n\nHuman respiratory system:\n• Nose/mouth - filter, warm, and moisten air\n• Trachea - windpipe with cartilage rings\n• Bronchi - main airways to lungs\n• Bronchioles - smaller airways\n• Alveoli - tiny air sacs for gas exchange\n\nGas exchange mechanism:\n• Oxygen diffuses from alveoli into blood capillaries\n• Carbon dioxide diffuses from blood into alveoli\n• Breathing is controlled by diaphragm and intercostal muscles\n\nComposition of air:\n• Inhaled air: 21% O₂, 0.03% CO₂, 79% N₂\n• Exhaled air: 16% O₂, 4% CO₂, 79% N₂\n\nEffects of smoking:\n• Tar blocks alveoli, reducing gas exchange\n• Damages cilia that clean airways\n• Causes cancer, bronchitis, emphysema\n• Reduces lung capacity\n\nAir pollution (dust, chemicals) similarly impairs lung function and can cause respiratory diseases."
        },
        {
          title: "Respiration - Aerobic and Anaerobic",
          outcomes: [
            "Appreciate that energy is obtained from food through respiration",
            "Explain the purpose of respiration",
            "Write equations for aerobic and anaerobic respiration",
            "Compare energy yields of different types"
          ],
          content: "Respiration is the process of releasing energy from glucose in living cells.\n\nAerobic respiration (with oxygen):\nGlucose + Oxygen → Carbon dioxide + Water + Energy (ATP)\nC₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + 36 ATP\n• Occurs in mitochondria\n• Complete breakdown of glucose\n• High energy yield\n\nAnaerobic respiration (without oxygen):\nIn yeast: Glucose → Ethanol + Carbon dioxide + Energy\nC₆H₁₂O₆ → 2C₂H₅OH + 2CO₂ + 2 ATP\n\nIn muscle cells: Glucose → Lactic acid + Energy\nC₆H₁₂O₆ → 2C₃H₆O₃ + 2 ATP\n\n• Incomplete breakdown\n• Low energy yield (only 2 ATP)\n• Emergency process when oxygen is limited\n\nApplications:\n• Fermentation in brewing (yeast produces alcohol)\n• Exercise - muscle 'burn' from lactic acid buildup\n• Oxygen debt after exercise\n\nBalance between aerobic and anaerobic depends on oxygen availability and energy demands."
        },
        {
          title: "Excretion in Animals",
          outcomes: [
            "Understand that animals remove metabolic wastes",
            "List human excretory organs and their functions",
            "Describe kidney structure and urine formation",
            "Understand dialysis and liver functions"
          ],
          content: "Excretion is the removal of metabolic waste products from the body.\n\nHuman excretory organs:\n• Kidneys - remove urea, excess water and salts\n• Liver - converts ammonia to urea, detoxifies substances\n• Lungs - remove carbon dioxide and water vapor\n• Skin - removes salts and water through sweat\n\nKidney structure:\n• Cortex - outer region containing glomeruli\n• Medulla - inner region with collecting ducts\n• Nephron - functional unit (glomerulus + tubule)\n• Renal artery/vein - blood supply\n• Ureter - carries urine to bladder\n\nUrine formation:\n1. Filtration - blood pressure forces water, urea, salts through glomerulus\n2. Reabsorption - useful substances (glucose, amino acids) reabsorbed in tubules\n3. Secretion - additional wastes added to urine\n\nKidneys maintain homeostasis by:\n• Regulating water balance\n• Controlling pH\n• Removing toxic wastes\n\nDialysis is artificial kidney treatment that filters blood when kidneys fail.\n\nLiver functions:\n• Converts toxic ammonia to less toxic urea\n• Breaks down old red blood cells\n• Detoxifies alcohol and drugs"
        },
        {
          title: "Chemical Coordination (Hormones)",
          outcomes: [
            "Appreciate that organs secrete hormones for coordination",
            "Differentiate hormones from enzymes",
            "Name key hormones and their effects",
            "Outline disorders and feedback control"
          ],
          content: "Hormones are chemical messengers released by endocrine glands into the bloodstream to control body functions.\n\nHormones vs Enzymes:\n• Hormones - coordinate body functions, act slowly, long-lasting effects\n• Enzymes - speed up reactions, act quickly, short-term effects\n\nMajor endocrine glands and hormones:\n• Pituitary - 'master gland' produces growth hormone, FSH, LH\n• Thyroid - thyroxine controls metabolism\n• Pancreas - insulin lowers blood glucose, glucagon raises it\n• Adrenal - adrenaline for 'fight or flight' response\n• Ovaries/testes - sex hormones for reproduction\n\nFeedback control (blood sugar regulation):\n• High glucose → pancreas releases insulin → glucose stored as glycogen\n• Low glucose → pancreas releases glucagon → glycogen converted to glucose\n\nHormonal disorders:\n• Diabetes - pancreas cannot produce/use insulin properly\n• Goitre - enlarged thyroid due to iodine deficiency\n• Osteoporosis - hormone imbalance affecting bone density\n\nPrevention through proper diet:\n• Iodine-rich foods for thyroid health\n• Balanced diet for diabetes management"
        },
        {
          title: "Nervous Coordination",
          outcomes: [
            "Appreciate that nerve impulses communicate between receptors and effectors",
            "Map the nervous system layout",
            "Define reflex action and draw reflex arc",
            "Be aware of substance abuse effects"
          ],
          content: "The nervous system coordinates body activities through electrical impulses.\n\nNervous system organization:\n• Central Nervous System (CNS) - brain and spinal cord\n• Peripheral Nervous System - all other nerves\n\nBrain regions:\n• Cerebrum - conscious thought, memory, voluntary actions\n• Cerebellum - balance, coordination, muscle memory\n• Medulla - involuntary actions (breathing, heart rate)\n\nNeuron types:\n• Sensory neurons - carry impulses from receptors to CNS\n• Motor neurons - carry impulses from CNS to effectors\n• Relay neurons - connect sensory and motor neurons in CNS\n\nReflex arc (automatic response):\nReceptor → Sensory neuron → Relay neuron → Motor neuron → Effector\n\nVoluntary vs Involuntary responses:\n• Voluntary - conscious control (raising hand)\n• Involuntary - automatic (knee-jerk reflex)\n\nEffects of drugs on nervous system:\n• Alcohol - slows reactions, impairs coordination\n• Stimulants (cigarettes) - affect brain chemistry\n• Marijuana - impairs memory and coordination\n\nSubstance abuse prevention:\n• Education about risks\n• Peer support\n• Healthy lifestyle choices"
        },
        {
          title: "Receptor Organs (Eye and Ear)",
          outcomes: [
            "Appreciate that sensory organs detect stimuli and enable response",
            "Describe eye parts and their functions",
            "Explain vision defects and correction",
            "Outline ear parts and hearing process"
          ],
          content: "Sensory organs convert external stimuli into nerve impulses.\n\nHuman eye structure:\n• Cornea - transparent layer that refracts light\n• Iris - colored part that controls pupil size\n• Lens - focuses light on retina (accommodation)\n• Retina - contains photoreceptors (rods and cones)\n• Optic nerve - carries impulses to brain\n• Ciliary muscles - change lens shape\n\nVision process:\n1. Light enters through cornea and pupil\n2. Lens focuses light on retina\n3. Photoreceptors convert light to nerve impulses\n4. Optic nerve transmits impulses to brain\n\nVision defects:\n• Myopia (short-sight) - can't see distant objects clearly\n  Correction: concave (diverging) lens\n• Hyperopia (long-sight) - can't see near objects clearly\n  Correction: convex (converging) lens\n• Astigmatism - uneven cornea curvature\n• Cataracts - lens becomes cloudy\n\nHuman ear structure:\n• Outer ear - ear canal and eardrum\n• Middle ear - three small bones (ossicles)\n• Inner ear - cochlea with hearing receptors\n\nHearing process:\n1. Sound waves enter ear canal\n2. Eardrum vibrates\n3. Ossicles amplify vibrations\n4. Cochlea converts vibrations to nerve impulses\n5. Auditory nerve carries impulses to brain\n\nHearing problems:\n• Noise pollution damage\n• Age-related hearing loss\n• Ear infections\n• Treatment: hearing aids, surgery"
        },
        {
          title: "Locomotion in Mammals",
          outcomes: [
            "Understand how muscles and skeleton interact to produce movement",
            "Outline skeletal system functions",
            "Name major bones and divisions",
            "Explain antagonistic muscle action"
          ],
          content: "The musculoskeletal system enables movement through interaction of bones, joints, and muscles.\n\nSkeletal system functions:\n• Support - gives body shape and framework\n• Protection - shields internal organs\n• Movement - provides attachment points for muscles\n• Blood cell production - bone marrow makes blood cells\n• Mineral storage - calcium and phosphorus\n\nSkeletal divisions:\n• Axial skeleton - skull, vertebral column, ribs\n• Appendicular skeleton - arms, legs, shoulder and hip girdles\n\nJoint types:\n• Ball and socket - hip, shoulder (circular movement)\n• Hinge - elbow, knee (movement in one plane)\n• Pivot - neck (rotational movement)\n• Fixed - skull sutures (no movement)\n\nMuscle action:\n• Muscles work in antagonistic pairs\n• One contracts while the other relaxes\n• Example: biceps contracts (triceps relaxes) to bend arm\n           triceps contracts (biceps relaxes) to straighten arm\n\nMuscle cramps:\n• Caused by sustained contraction\n• Due to fatigue, dehydration, or lack of minerals\n• Prevention: stretching, proper hydration, balanced diet\n\nLever systems:\n• Bones act as levers\n• Joints are fulcrums\n• Muscles provide effort to move loads"
        },
        {
          title: "Growth in Plants and Animals",
          outcomes: [
            "Understand how organisms change in size over life",
            "Distinguish growth vs development",
            "Outline mitosis and its role",
            "Study seed germination and growth curves"
          ],
          content: "Growth is the permanent increase in size and mass of an organism.\n\nGrowth vs Development:\n• Growth - increase in size, weight, number of cells\n• Development - maturation, differentiation, functional changes\n\nCell division (mitosis):\n• Produces two identical daughter cells\n• Increases cell number for growth\n• Maintains chromosome number\n• Occurs throughout life for growth and repair\n\nSeed structure and germination:\nMonocot seed (maize):\n• One cotyledon (seed leaf)\n• Endosperm stores food\n• Parallel leaf venation\n\nDicot seed (bean):\n• Two cotyledons store food\n• No endosperm\n• Network leaf venation\n\nGermination conditions:\n• Water - softens seed coat, activates enzymes\n• Oxygen - needed for respiration\n• Suitable temperature - optimal enzyme activity\n• Light may be required for some seeds\n\nGermination process:\n1. Water absorption (imbibition)\n2. Enzyme activation\n3. Food mobilization\n4. Radicle (root) emerges first\n5. Plumule (shoot) emerges\n\nGrowth curves:\n• Plot height/mass against time\n• Show slow start, rapid growth, then slowing\n• S-shaped curve typical for most organisms"
        },
        {
          title: "Development in Plants and Animals",
          outcomes: [
            "Understand that organisms go through structural and functional changes",
            "Give examples of metamorphosis vs direct development",
            "Explain human puberty changes",
            "Recognize plant development stages"
          ],
          content: "Development involves complex, often irreversible changes beyond mere size increase.\n\nTypes of development:\n\nComplete metamorphosis (insects):\nEgg → Larva → Pupa → Adult\n• Butterfly: caterpillar looks completely different from adult\n• Different life stages exploit different niches\n\nIncomplete metamorphosis (insects):\nEgg → Nymph → Adult\n• Grasshopper: nymph resembles small adult\n• Gradual development with molting\n\nAmphibian metamorphosis:\nEgg → Tadpole → Froglet → Adult frog\n• Tadpole has gills, tail (aquatic)\n• Adult has lungs, legs (terrestrial)\n\nDirect development (mammals):\nEgg → Embryo → Fetus → Baby → Adult\n• No dramatic body plan changes\n• Gradual growth and maturation\n\nHuman puberty:\n• Triggered by hormones (testosterone, estrogen)\n• Physical changes: growth spurts, body hair, voice changes\n• Reproductive maturity\n• Emotional and social development\n\nPlant development:\n• Vegetative growth - roots, stems, leaves\n• Reproductive development - flowering\n• Senescence - aging and death\n• Triggered by age, environmental factors\n\nDevelopment is controlled by:\n• Genes - provide the blueprint\n• Hormones - trigger changes\n• Environment - influences timing and extent"
        }
      ],
      S4: [
        {
          title: "Asexual Reproduction in Plants (Vegetative Propagation)",
          outcomes: [
            "Appreciate that some plant parts can develop into new independent plants",
            "Know asexual reproduction means one parent with no gametes",
            "Describe natural and artificial vegetative methods",
            "Understand advantages and disadvantages"
          ],
          content: "Asexual reproduction produces offspring from one parent without gametes, resulting in genetically identical clones.\n\nNatural vegetative propagation:\n• Runners - horizontal stems (strawberry, spider plant)\n• Tubers - underground stems (potato, yam)\n• Bulbs - underground storage organs (onion, garlic)\n• Corms - short underground stems (taro)\n• Suckers - shoots from roots (banana, pineapple)\n\nArtificial methods:\n• Cuttings - stem/leaf pieces planted (sweet potato, cassava)\n• Grafting - joining parts of two plants (fruit trees)\n• Layering - bending branch to soil while attached\n• Tissue culture - growing plants from cells\n\nAdvantages:\n• Rapid multiplication\n• True-to-type offspring (maintains desirable traits)\n• No pollinator needed\n• Can propagate seedless varieties\n• Faster than sexual reproduction\n\nDisadvantages:\n• No genetic variation\n• Disease spreads easily through clones\n• May lack vigor over time\n• Limited adaptation to environment\n\nAgricultural importance:\n• Commercial crops: bananas, potatoes, sugarcane\n• Fruit tree propagation\n• Maintaining hybrid varieties\n• Conservation of rare species"
        },
        {
          title: "Sexual Reproduction in Plants",
          outcomes: [
            "Understand that flowers are specialized organs for sexual reproduction",
            "Identify flower parts and their roles",
            "Distinguish self vs cross pollination",
            "Explain seed and fruit development"
          ],
          content: "Sexual reproduction in flowering plants involves fusion of male and female gametes.\n\nFlower structure:\n• Sepals - protect flower bud (calyx collectively)\n• Petals - attract pollinators (corolla collectively)\n• Stamens - male parts:\n  - Anther - produces pollen (male gametes)\n  - Filament - supports anther\n• Carpels - female parts:\n  - Stigma - receives pollen\n  - Style - connects stigma to ovary\n  - Ovary - contains ovules (female gametes)\n\nPollination types:\n• Self-pollination - pollen from same flower/plant\n  Advantages: guaranteed reproduction, maintains pure lines\n  Disadvantages: no variation, inbreeding problems\n\n• Cross-pollination - pollen from different plant\n  Advantages: genetic variation, hybrid vigor\n  Disadvantages: relies on pollinators, may not occur\n\nPollination agents:\n• Wind - light pollen, feathery stigma (grasses)\n• Insects - colorful petals, nectar, heavy pollen (roses)\n• Birds - tubular flowers, bright colors (hibiscus)\n• Water - aquatic plants\n\nFertilization and development:\n1. Pollen lands on stigma\n2. Pollen tube grows down style\n3. Male gametes travel to ovule\n4. Fertilization occurs\n5. Ovule develops into seed\n6. Ovary develops into fruit\n\nSeed vs Fruit:\n• Seed - develops from fertilized ovule, contains embryo\n• Fruit - develops from ovary, protects and disperses seeds\n\nSeed dispersal methods:\n• Wind - light seeds with wings/parachutes (dandelion)\n• Animals - fleshy fruits eaten, seeds pass through (mango)\n• Water - buoyant seeds (coconut)\n• Explosive - pods burst open (peas)\n• Hooks - attach to animals (burdock)"
        },
        {
          title: "Sexual Reproduction in Humans",
          outcomes: [
            "Understand that sexual reproduction involves two parents with specialized systems",
            "Know male and female reproductive structures",
            "Outline menstrual cycle and fertilization",
            "Recognize importance of antenatal care and STI prevention"
          ],
          content: "Human sexual reproduction involves specialized reproductive systems in males and females.\n\nMale reproductive system:\n• Testes - produce sperm and testosterone\n• Epididymis - stores and matures sperm\n• Vas deferens - carries sperm during ejaculation\n• Seminal vesicles - produce seminal fluid\n• Prostate gland - produces alkaline fluid\n• Penis - delivers sperm to female\n\nFemale reproductive system:\n• Ovaries - produce eggs and hormones (estrogen, progesterone)\n• Fallopian tubes - site of fertilization\n• Uterus - houses developing embryo/fetus\n• Cervix - neck of uterus\n• Vagina - birth canal and copulation\n\nMenstrual cycle (28 days average):\n• Days 1-5: Menstruation (shedding of uterine lining)\n• Days 6-13: Follicular phase (egg maturation)\n• Day 14: Ovulation (egg release)\n• Days 15-28: Luteal phase (uterine lining thickens)\n\nHormonal control:\n• FSH - stimulates egg development\n• LH - triggers ovulation\n• Estrogen - develops uterine lining\n• Progesterone - maintains pregnancy\n\nFertilization and development:\n1. Sperm fertilizes egg in fallopian tube\n2. Zygote divides forming embryo\n3. Implantation in uterus wall\n4. Embryo develops into fetus\n5. Birth after 9 months gestation\n\nPlacenta functions:\n• Exchanges nutrients and oxygen\n• Removes waste products\n• Produces hormones\n• Barrier against some pathogens\n\nAntenatal care:\n• Regular medical checkups\n• Proper nutrition\n• Avoid alcohol/drugs/smoking\n• Folic acid supplements\n• Monitor fetal development\n\nPostnatal care:\n• Breastfeeding (colostrum provides immunity)\n• Immunizations\n• Regular health checks\n• Proper nutrition\n\nBirth control methods:\n• Barrier methods - condoms, diaphragm\n• Hormonal - pills, injections\n• IUD - intrauterine device\n• Natural - rhythm method\n• Permanent - sterilization\n• Abstinence - safest for youth\n\nSTI prevention:\n• Abstinence (recommended for youth)\n• Faithful partnerships\n• Condom use\n• Regular testing\n• Education about risks\n\nCommon STIs:\n• HIV/AIDS - attacks immune system\n• Gonorrhea - bacterial infection\n• Syphilis - bacterial infection\n• HPV - viral infection, can cause cancer"
        },
        {
          title: "Inheritance (Genetics)",
          outcomes: [
            "Appreciate that characteristics are transmitted from parents to offspring",
            "Explain how cells divide by meiosis",
            "Learn simple Punnett squares for monohybrid crosses",
            "Understand sex determination and sex-linked inheritance"
          ],
          content: "Heredity is the transmission of characteristics from parents to offspring through genes.\n\nBasic genetics concepts:\n• DNA - contains genetic information\n• Chromosomes - structures containing genes\n• Genes - sections of DNA coding for traits\n• Alleles - different forms of the same gene\n• Genotype - genetic makeup (e.g., Tt)\n• Phenotype - observable characteristics (e.g., tall)\n\nCell division types:\n• Mitosis - produces identical diploid cells for growth\n• Meiosis - produces genetically different gametes (halves chromosome number)\n\nMendelian inheritance:\n• Dominant alleles - expressed when present (capital letter, e.g., T)\n• Recessive alleles - only expressed when homozygous (small letter, e.g., t)\n\nMonohybrid cross example (tall vs short peas):\nParents: TT (tall) × tt (short)\nF1: All Tt (tall - dominant masks recessive)\nF1 × F1: Tt × Tt\nF2: TT : Tt : Tt : tt = 1:2:1 genotypic ratio\n    Tall : Short = 3:1 phenotypic ratio\n\nSex determination:\n• Females: XX (homogametic)\n• Males: XY (heterogametic)\n• Males determine offspring sex\n\nSex-linked inheritance:\n• Genes located on X chromosome\n• Males more affected (only one X)\n• Examples: color blindness, hemophilia\n\nColor blindness cross:\nCarrier female (XᶜX) × Normal male (XY)\nOffspring: XᶜX (carrier daughter), XX (normal daughter), XᶜY (color blind son), XY (normal son)\n\nSignificance of meiosis:\n• Reduces chromosome number (diploid to haploid)\n• Creates genetic variation through:\n  - Independent assortment\n  - Crossing over\n• Essential for sexual reproduction"
        },
        {
          title: "Variation and Natural Selection",
          outcomes: [
            "Understand that variation results from genetic makeup changes",
            "Distinguish genetic vs environmental variation",
            "Understand mutations and genetic disorders",
            "Describe natural selection principles"
          ],
          content: "Variation is differences between individuals of the same species.\n\nTypes of variation:\n• Genetic variation - caused by:\n  - Mutations (changes in DNA)\n  - Meiosis (independent assortment, crossing over)\n  - Sexual reproduction (gene combinations)\n\n• Environmental variation - caused by:\n  - Nutrition (stunted growth from poor diet)\n  - Climate (sun exposure affecting skin color)\n  - Exercise (muscle development)\n  - Disease (effects on growth)\n\nMutations:\n• Beneficial - provide survival advantage (antibiotic resistance)\n• Neutral - no significant effect\n• Harmful - cause genetic disorders\n\nGenetic disorders:\n• Sickle cell anemia - mutated hemoglobin gene\n  - Causes pain, organ damage\n  - Heterozygotes resistant to malaria (advantage in malaria areas)\n• Albinism - lack of melanin pigment\n• Down syndrome - extra chromosome 21\n• Cystic fibrosis - thick mucus production\n\nNatural selection:\n• Proposed by Charles Darwin\n• Individuals with advantageous traits survive and reproduce\n• These traits become more common over time\n• Drives evolution\n\nNatural selection requirements:\n• Variation in population\n• Inheritance of traits\n• Differential survival and reproduction\n• Time\n\nExample - Peppered moths:\n• Light moths camouflaged on light tree bark\n• Industrial pollution darkened trees\n• Dark moths now had advantage\n• Population shifted to more dark moths\n• Shows adaptation to environment\n\nArtificial selection:\n• Humans choose organisms with desired traits\n• Selective breeding over generations\n• Examples:\n  - High-yield crop varieties\n  - Dairy cows with high milk production\n  - Dog breeds with specific characteristics\n  - Faster-growing fish\n\nImportance of variation:\n• Allows species to adapt to environmental changes\n• Without variation, populations cannot evolve\n• Basis for selective breeding programs\n• Essential for species survival"
        },
        {
          title: "Concept of Ecology",
          outcomes: [
            "Understand the concepts of communities, habitats, and ecosystems",
            "Define key ecological terms",
            "Recognize ecosystem examples",
            "Distinguish biotic and abiotic factors"
          ],
          content: "Ecology is the study of organisms and their interactions with each other and their environment.\n\nKey ecological terms:\n• Species - group of organisms that can interbreed to produce fertile offspring\n• Population - all members of a species in a particular area\n• Community - all populations of different species in an area\n• Habitat - the place where an organism lives\n• Ecosystem - community plus the physical environment\n• Biosphere - all ecosystems on Earth\n\nEcosystem examples:\n• Forest ecosystem - trees, animals, soil, climate\n• Savanna ecosystem - grasslands with scattered trees\n• Aquatic ecosystem - lake, river, or marine environment\n• Desert ecosystem - low rainfall, specialized organisms\n• Agricultural ecosystem - crops, livestock, managed environment\n\nBiotic factors (living):\n• Producers - plants that make their own food\n• Primary consumers - herbivores that eat plants\n• Secondary consumers - carnivores that eat herbivores\n• Decomposers - bacteria and fungi that break down dead matter\n• Predators and prey\n• Parasites and hosts\n• Competitors for resources\n\nAbiotic factors (non-living):\n• Temperature - affects enzyme activity and metabolism\n• Light - needed for photosynthesis\n• Water - essential for all life processes\n• Soil pH - affects nutrient availability\n• Oxygen levels - needed for respiration\n• Minerals - required for growth\n• Topography - slope and elevation effects\n\nEcosystem characteristics:\n• Energy flows through ecosystems (sun → producers → consumers)\n• Nutrients cycle within ecosystems\n• Dynamic equilibrium - populations fluctuate but remain relatively stable\n• Interdependence - organisms depend on each other\n• Adaptation - organisms suited to their environment\n\nImportance of ecology:\n• Understanding environmental problems\n• Conservation of biodiversity\n• Sustainable resource management\n• Predicting effects of human activities\n• Managing agricultural systems"
        }
      ]
    }
  },
  {
    id: 'chemistry',
    title: 'Chemistry',
    icon: TestTube,
    color: 'chemistry',
    topics: {
      S1: [
        {
          title: "Introduction to Chemistry",
          outcomes: [
            "Define chemistry and its importance",
            "Understand laboratory safety",
            "Identify common laboratory equipment"
          ],
          content: "Chemistry is the study of matter and the changes it undergoes. It helps us understand the world around us and develop new materials.\n\nLaboratory Safety Rules:\n• Always wear safety goggles\n• Tie back long hair\n• No eating or drinking in the lab\n• Read labels carefully\n• Report accidents immediately\n• Wash hands after experiments\n\nCommon lab equipment:\n• Beakers, test tubes, flasks\n• Bunsen burner\n• Measuring cylinders\n• Balance for weighing"
        }
      ],
      S2: [
        {
          title: "States of Matter",
          outcomes: [
            "Identify three states of matter",
            "Explain particle arrangement in each state",
            "Describe changes between states"
          ],
          content: "Matter exists in three main states:\n\n1. Solid\n• Particles closely packed\n• Definite shape and volume\n• Particles vibrate in fixed positions\n\n2. Liquid\n• Particles close but can move\n• Definite volume, takes shape of container\n• Particles can slide past each other\n\n3. Gas\n• Particles far apart and move freely\n• No definite shape or volume\n• Particles move rapidly in all directions"
        }
      ],
      S3: [
        {
          title: "Chemical Reactions",
          outcomes: [
            "Identify types of chemical reactions",
            "Balance chemical equations",
            "Understand reaction conditions"
          ],
          content: "Chemical reactions involve the rearrangement of atoms to form new substances.\n\nTypes of reactions:\n• Synthesis (A + B → AB)\n• Decomposition (AB → A + B)\n• Single replacement (A + BC → AC + B)\n• Double replacement (AB + CD → AD + CB)\n• Combustion (fuel + oxygen → products)\n\nFactors affecting reaction rate:\n• Temperature\n• Concentration\n• Surface area\n• Catalysts"
        }
      ],
      S4: [
        {
          title: "Organic Chemistry",
          outcomes: [
            "Understand carbon compounds",
            "Identify functional groups",
            "Name simple organic compounds"
          ],
          content: "Organic chemistry studies carbon compounds. Carbon can form four bonds, creating diverse molecules.\n\nMain groups:\n• Alkanes (single bonds): methane, ethane\n• Alkenes (double bonds): ethene\n• Alkynes (triple bonds): ethyne\n• Alcohols: methanol, ethanol\n• Carboxylic acids: acetic acid\n\nFunctional groups determine chemical properties:\n• -OH (alcohol group)\n• -COOH (carboxyl group)\n• -CHO (aldehyde group)"
        }
      ]
    }
  },
  {
    id: 'physics',
    title: 'Physics',
    icon: Zap,
    color: 'physics',
    topics: {
      S1: [
        {
          title: "Measurements and Units",
          outcomes: [
            "Use SI units correctly",
            "Make accurate measurements",
            "Calculate using scientific notation"
          ],
          content: "Physics uses standard units to measure quantities.\n\nSI Base Units:\n• Length: meter (m)\n• Mass: kilogram (kg)\n• Time: second (s)\n• Temperature: Kelvin (K)\n• Electric current: ampere (A)\n\nPrefixes:\n• kilo (k) = 1000\n• centi (c) = 0.01\n• milli (m) = 0.001\n• micro (μ) = 0.000001\n\nMeasuring instruments:\n• Ruler for length\n• Balance for mass\n• Stopwatch for time\n• Thermometer for temperature"
        }
      ],
      S2: [
        {
          title: "Forces and Motion",
          outcomes: [
            "Define force and its effects",
            "Calculate speed and acceleration",
            "Apply Newton's laws"
          ],
          content: "Forces can change an object's motion, shape, or direction.\n\nTypes of forces:\n• Contact forces (push, pull, friction)\n• Non-contact forces (gravity, magnetic, electric)\n\nNewton's Laws:\n1. First Law: Objects at rest stay at rest unless acted upon by a force\n2. Second Law: F = ma (Force = mass × acceleration)\n3. Third Law: For every action, there's an equal and opposite reaction\n\nSpeed = distance ÷ time\nAcceleration = change in velocity ÷ time"
        }
      ],
      S3: [
        {
          title: "Energy and Work",
          outcomes: [
            "Define different forms of energy",
            "Calculate work and power",
            "Apply conservation of energy"
          ],
          content: "Energy is the ability to do work.\n\nForms of energy:\n• Kinetic energy (motion)\n• Potential energy (position)\n• Chemical energy (bonds)\n• Electrical energy\n• Heat energy\n• Light energy\n• Sound energy\n\nWork = Force × Distance\nPower = Work ÷ Time\n\nLaw of Conservation of Energy:\nEnergy cannot be created or destroyed, only transformed from one form to another."
        }
      ],
      S4: [
        {
          title: "Electricity and Magnetism",
          outcomes: [
            "Understand electric circuits",
            "Calculate current, voltage, and resistance",
            "Explain electromagnetic phenomena"
          ],
          content: "Electricity involves the flow of electric charge.\n\nBasic circuit components:\n• Battery (voltage source)\n• Resistor (opposes current flow)\n• Switch (controls current)\n• Wires (conduct current)\n\nOhm's Law: V = I × R\n• V = Voltage (volts)\n• I = Current (amperes)\n• R = Resistance (ohms)\n\nMagnetism:\n• Magnets have north and south poles\n• Like poles repel, unlike poles attract\n• Electric current creates magnetic fields\n• Moving magnets can generate electricity"
        }
      ]
    }
  },
  {
    id: 'mathematics',
    title: 'Mathematics',
    icon: Calculator,
    color: 'mathematics',
    topics: {
      S1: [
        {
          title: "Number Systems",
          outcomes: [
            "Work with whole numbers and fractions",
            "Understand place value",
            "Perform basic operations"
          ],
          content: "Mathematics begins with understanding numbers and their relationships.\n\nTypes of numbers:\n• Natural numbers: 1, 2, 3, 4...\n• Whole numbers: 0, 1, 2, 3, 4...\n• Integers: ...-2, -1, 0, 1, 2...\n• Fractions: parts of a whole\n• Decimals: another way to write fractions\n\nPlace value in decimals:\nThousands | Hundreds | Tens | Units | . | Tenths | Hundredths\n\nOrder of operations (BODMAS):\nBrackets, Orders, Division/Multiplication, Addition/Subtraction"
        }
      ],
      S2: [
        {
          title: "Algebra Basics",
          outcomes: [
            "Use letters to represent numbers",
            "Solve simple equations",
            "Substitute values into expressions"
          ],
          content: "Algebra uses letters (variables) to represent unknown numbers.\n\nBasic rules:\n• x + x = 2x\n• x × x = x²\n• 3x means 3 × x\n• x + 5 = 12, so x = 7\n\nSolving equations:\n1. Isolate the variable\n2. Perform same operation on both sides\n3. Check your answer\n\nExample: 2x + 3 = 11\n2x = 11 - 3 = 8\nx = 8 ÷ 2 = 4"
        }
      ],
      S3: [
        {
          title: "Geometry",
          outcomes: [
            "Identify geometric shapes",
            "Calculate areas and perimeters",
            "Understand angles and their properties"
          ],
          content: "Geometry studies shapes, sizes, and positions.\n\nBasic shapes:\n• Triangle: 3 sides, angles sum to 180°\n• Square: 4 equal sides, 4 right angles\n• Rectangle: opposite sides equal, 4 right angles\n• Circle: all points equidistant from center\n\nArea formulas:\n• Rectangle: length × width\n• Triangle: ½ × base × height\n• Circle: π × radius²\n\nAngle types:\n• Acute: less than 90°\n• Right: exactly 90°\n• Obtuse: greater than 90°\n• Straight: exactly 180°"
        }
      ],
      S4: [
        {
          title: "Statistics and Probability",
          outcomes: [
            "Collect and analyze data",
            "Calculate averages",
            "Understand probability concepts"
          ],
          content: "Statistics helps us understand and interpret data.\n\nMeasures of central tendency:\n• Mean: sum of values ÷ number of values\n• Median: middle value when arranged in order\n• Mode: most frequently occurring value\n\nData representation:\n• Bar charts\n• Pie charts\n• Line graphs\n• Histograms\n\nProbability:\n• Probability = favorable outcomes ÷ total possible outcomes\n• Always between 0 and 1\n• 0 = impossible, 1 = certain\n• Can be expressed as fractions, decimals, or percentages"
        }
      ]
    }
  },
  {
    id: 'ict',
    title: 'ICT / Computer Studies',
    icon: Monitor,
    color: 'ict',
    topics: {
      S1: [
        {
          title: "Introduction to ICT",
          outcomes: [
            "Define ICT and its importance",
            "Identify computer components",
            "Practice basic computer operations"
          ],
          content: "ICT (Information and Communication Technology) involves using computers and digital devices to process, store, and share information.\n\nComputer components:\n• Input devices: keyboard, mouse, microphone\n• Output devices: monitor, printer, speakers\n• Processing unit: CPU (Central Processing Unit)\n• Storage devices: hard drive, USB, CD/DVD\n• Memory: RAM (Random Access Memory)\n\nBasic operations:\n• Starting and shutting down\n• Using keyboard and mouse\n• Opening and closing programs\n• Saving and opening files"
        }
      ],
      S2: [
        {
          title: "Word Processing",
          outcomes: [
            "Create and format documents",
            "Use basic editing features",
            "Apply formatting styles"
          ],
          content: "Word processing software helps create, edit, and format text documents.\n\nBasic features:\n• Typing and editing text\n• Cut, copy, and paste\n• Find and replace\n• Spell check\n• Save and print\n\nFormatting options:\n• Font type, size, and color\n• Bold, italic, underline\n• Alignment (left, center, right, justify)\n• Bullet points and numbering\n• Headers and footers\n• Page margins and orientation"
        }
      ],
      S3: [
        {
          title: "Spreadsheets and Data",
          outcomes: [
            "Create and format spreadsheets",
            "Use formulas and functions",
            "Create charts and graphs"
          ],
          content: "Spreadsheets organize data in rows and columns for calculations and analysis.\n\nBasic concepts:\n• Cells, rows, and columns\n• Cell references (A1, B2, etc.)\n• Data types: numbers, text, dates\n• Formulas start with = sign\n\nCommon functions:\n• SUM() - adds numbers\n• AVERAGE() - calculates mean\n• COUNT() - counts cells with numbers\n• MAX() - finds largest value\n• MIN() - finds smallest value\n\nChart types:\n• Bar charts\n• Line graphs\n• Pie charts"
        }
      ],
      S4: [
        {
          title: "Internet and Digital Citizenship",
          outcomes: [
            "Navigate the internet safely",
            "Understand digital citizenship",
            "Practice online communication"
          ],
          content: "The internet connects computers worldwide, providing access to information and communication.\n\nInternet safety:\n• Use strong passwords\n• Don't share personal information\n• Be careful with downloads\n• Report inappropriate content\n• Verify information sources\n\nDigital citizenship:\n• Respect others online\n• Avoid cyberbullying\n• Respect copyright laws\n• Maintain digital footprint\n• Use technology ethically\n\nOnline tools:\n• Email communication\n• Search engines\n• Social media (age-appropriate)\n• Educational websites\n• Online collaboration tools"
        }
      ]
    }
  },
  {
    id: 'technology',
    title: 'Technology & Design',
    icon: Wrench,
    color: 'technology',
    topics: {
      S1: [
        {
          title: "Introduction to Technology",
          outcomes: [
            "Understand what technology is",
            "Identify everyday technologies",
            "Learn basic design principles"
          ],
          content: "Technology is the application of knowledge to solve problems and improve life.\n\nTypes of technology:\n• Simple machines: lever, pulley, wheel\n• Communication: telephone, internet, radio\n• Transportation: cars, planes, bicycles\n• Medical: X-rays, prosthetics, medicines\n• Construction: tools, materials, techniques\n\nDesign process:\n1. Identify the problem\n2. Research and brainstorm\n3. Design solutions\n4. Build and test\n5. Evaluate and improve\n\nBasic tools:\n• Measuring tools: ruler, square\n• Cutting tools: saw, scissors\n• Joining tools: hammer, screwdriver\n• Safety equipment: goggles, gloves"
        }
      ],
      S2: [
        {
          title: "Materials and Properties",
          outcomes: [
            "Identify common materials",
            "Understand material properties",
            "Select appropriate materials for tasks"
          ],
          content: "Different materials have different properties that make them suitable for specific uses.\n\nCommon materials:\n• Wood: strong, lightweight, renewable\n• Metal: strong, durable, conducts heat\n• Plastic: lightweight, waterproof, moldable\n• Glass: transparent, brittle, non-porous\n• Fabric: flexible, breathable, washable\n\nMaterial properties:\n• Strength: resistance to breaking\n• Hardness: resistance to scratching\n• Flexibility: ability to bend\n• Durability: how long it lasts\n• Weight: heavy or light\n• Cost: expensive or affordable"
        }
      ],
      S3: [
        {
          title: "Structures and Mechanisms",
          outcomes: [
            "Understand structural principles",
            "Identify types of mechanisms",
            "Design stable structures"
          ],
          content: "Structures support loads and mechanisms create movement.\n\nStructural elements:\n• Beams: horizontal supports\n• Columns: vertical supports\n• Trusses: triangular frameworks\n• Foundations: base supports\n• Joints: connections between parts\n\nTypes of mechanisms:\n• Levers: amplify force\n• Gears: change speed or direction\n• Pulleys: lift heavy objects\n• Linkages: transfer motion\n• Cams: convert rotary to linear motion\n\nDesign considerations:\n• Load requirements\n• Safety factors\n• Environmental conditions\n• Cost and materials\n• Aesthetics and function"
        }
      ],
      S4: [
        {
          title: "Systems and Control",
          outcomes: [
            "Understand system components",
            "Design control systems",
            "Apply feedback principles"
          ],
          content: "Systems have inputs, processes, and outputs. Control systems regulate behavior.\n\nSystem components:\n• Input: what goes into the system\n• Process: what the system does\n• Output: what comes out\n• Feedback: information about performance\n• Control: regulation of the system\n\nTypes of control:\n• Manual: human operated\n• Automatic: self-regulating\n• Programmable: computer controlled\n\nExamples:\n• Thermostat: controls temperature\n• Traffic lights: control traffic flow\n• Washing machine: automated cycles\n• Burglar alarm: security system\n\nControl methods:\n• Switches and sensors\n• Timers and counters\n• Logic gates\n• Microcontrollers"
        }
      ]
    }
  },
  {
    id: 'art',
    title: 'Art & Design',
    icon: Palette,
    color: 'art',
    topics: {
      S1: [
        {
          title: "Basic Drawing Skills",
          outcomes: [
            "Use basic drawing tools correctly",
            "Understand line, shape, and form",
            "Practice observation drawing"
          ],
          content: "Drawing is the foundation of visual art. It helps develop observation skills and creativity.\n\nBasic drawing tools:\n• Pencils (2H, HB, 2B, 4B)\n• Erasers (kneaded, plastic)\n• Paper (sketch, drawing)\n• Rulers and guides\n• Blending tools\n\nElements of art:\n• Line: marks that connect points\n• Shape: 2D enclosed areas\n• Form: 3D objects with volume\n• Value: lightness and darkness\n• Texture: surface quality\n• Color: hue, saturation, brightness\n• Space: area around objects\n\nDrawing techniques:\n• Contour drawing\n• Shading and blending\n• Cross-hatching\n• Stippling\n• Gesture drawing"
        }
      ],
      S2: [
        {
          title: "Color Theory and Painting",
          outcomes: [
            "Understand color relationships",
            "Mix colors effectively",
            "Apply painting techniques"
          ],
          content: "Color theory explains how colors work together and affect our emotions.\n\nColor wheel:\n• Primary colors: red, blue, yellow\n• Secondary colors: orange, green, purple\n• Tertiary colors: mix of primary and secondary\n\nColor properties:\n• Hue: the color itself\n• Saturation: intensity or purity\n• Value: lightness or darkness\n• Temperature: warm or cool\n\nColor schemes:\n• Monochromatic: one color + tints/shades\n• Analogous: neighboring colors\n• Complementary: opposite colors\n• Triadic: three evenly spaced colors\n\nPainting media:\n• Watercolor: transparent, flowing\n• Acrylic: fast-drying, versatile\n• Oil: slow-drying, blendable\n• Tempera: opaque, matte finish"
        }
      ],
      S3: [
        {
          title: "Design Principles",
          outcomes: [
            "Apply design principles in artwork",
            "Create balanced compositions",
            "Understand visual hierarchy"
          ],
          content: "Design principles guide how elements are arranged to create effective visual communication.\n\nPrinciples of design:\n• Balance: visual weight distribution\n• Contrast: differences that create interest\n• Emphasis: focal points that draw attention\n• Movement: visual flow through the artwork\n• Pattern: repeated elements\n• Rhythm: regular repetition\n• Unity: how elements work together\n\nTypes of balance:\n• Symmetrical: mirror image\n• Asymmetrical: different but balanced\n• Radial: radiating from a center\n\nCreating emphasis:\n• Size and scale\n• Color contrast\n• Positioning\n• Isolation\n• Detail and texture\n\nComposition techniques:\n• Rule of thirds\n• Leading lines\n• Framing\n• Depth and perspective"
        }
      ],
      S4: [
        {
          title: "3D Art and Sculpture",
          outcomes: [
            "Understand 3D design principles",
            "Work with various sculptural materials",
            "Create functional and decorative objects"
          ],
          content: "Three-dimensional art occupies space and can be viewed from multiple angles.\n\nSculpture techniques:\n• Additive: building up materials\n• Subtractive: removing materials\n• Modeling: shaping soft materials\n• Casting: pouring into molds\n• Assembling: joining found objects\n\nCommon materials:\n• Clay: moldable, fired for permanence\n• Wood: carved, joined, finished\n• Stone: carved, polished\n• Metal: welded, forged, cast\n• Paper/cardboard: folded, cut, glued\n• Found objects: recycled materials\n\n3D design elements:\n• Form: actual 3D volume\n• Space: positive and negative areas\n• Texture: actual surface quality\n• Scale: relative size\n• Proportion: size relationships\n\nFunctional vs. decorative:\n• Functional: pottery, furniture, tools\n• Decorative: sculptures, ornaments"
        }
      ]
    }
  },
  {
    id: 'religious',
    title: 'Religious Education',
    icon: Church,
    color: 'religious',
    topics: {
      S1: [
        {
          title: "Introduction to Religious Studies",
          outcomes: [
            "Understand the role of religion in society",
            "Identify major world religions",
            "Practice religious tolerance"
          ],
          content: "Religious education promotes understanding of different faiths and moral values.\n\nMajor world religions:\n• Christianity: follows Jesus Christ\n• Islam: follows Prophet Muhammad\n• Judaism: one of the oldest monotheistic religions\n• Hinduism: diverse traditions from India\n• Buddhism: follows Buddha's teachings\n• Traditional African religions: ancestor worship\n\nCommon religious practices:\n• Prayer and meditation\n• Sacred texts and scriptures\n• Religious festivals and celebrations\n• Places of worship\n• Religious leaders and communities\n• Moral and ethical teachings\n\nValues taught by religions:\n• Love and compassion\n• Honesty and truthfulness\n• Respect for others\n• Care for the environment\n• Peace and forgiveness\n• Justice and fairness"
        }
      ],
      S2: [
        {
          title: "Christian Religious Education",
          outcomes: [
            "Know key biblical stories",
            "Understand Christian beliefs",
            "Apply Christian values in daily life"
          ],
          content: "Christianity is based on the life and teachings of Jesus Christ as recorded in the Bible.\n\nKey Christian beliefs:\n• God as Trinity: Father, Son, Holy Spirit\n• Jesus as Savior and Lord\n• Salvation through faith\n• Eternal life after death\n• The Bible as God's word\n\nImportant biblical stories:\n• Creation (Genesis)\n• Noah's Ark (Genesis)\n• Moses and the Exodus\n• David and Goliath\n• Birth of Jesus (Christmas)\n• Death and Resurrection (Easter)\n• Parables of Jesus\n\nChristian values:\n• Love God and neighbor\n• Forgiveness and mercy\n• Helping the poor and needy\n• Honesty and integrity\n• Peace and reconciliation"
        }
      ],
      S3: [
        {
          title: "Islamic Religious Education",
          outcomes: [
            "Understand Islamic teachings",
            "Know the Five Pillars of Islam",
            "Apply Islamic values in life"
          ],
          content: "Islam is based on the teachings of Prophet Muhammad as revealed in the Quran.\n\nFive Pillars of Islam:\n1. Shahada: Declaration of faith\n2. Salah: Five daily prayers\n3. Zakat: Giving to charity\n4. Sawm: Fasting during Ramadan\n5. Hajj: Pilgrimage to Mecca\n\nCore Islamic beliefs:\n• Allah is the one God\n• Muhammad is His messenger\n• The Quran is God's final revelation\n• Angels exist and serve God\n• Day of Judgment\n• Predestination (Qadar)\n\nIslamic values:\n• Submission to Allah\n• Compassion and mercy\n• Justice and equality\n• Knowledge and learning\n• Community and brotherhood\n• Charity and helping others"
        }
      ],
      S4: [
        {
          title: "Comparative Religion and Ethics",
          outcomes: [
            "Compare different religious traditions",
            "Understand interfaith dialogue",
            "Apply universal ethical principles"
          ],
          content: "Studying different religions promotes understanding and peaceful coexistence.\n\nCommon themes across religions:\n• Belief in divine or spiritual reality\n• Sacred texts and oral traditions\n• Moral and ethical guidelines\n• Community worship and fellowship\n• Life after death concepts\n• Golden Rule: treat others well\n\nInterfaith dialogue:\n• Respect for different beliefs\n• Finding common ground\n• Learning from each other\n• Working together for peace\n• Addressing social issues together\n\nUniversal ethical principles:\n• Respect for human dignity\n• Care for the environment\n• Social justice and equality\n• Peaceful conflict resolution\n• Responsibility for community\n• Compassion for all beings\n\nReligion and society:\n• Role in education and healthcare\n• Influence on laws and governance\n• Art, music, and architecture\n• Festivals and cultural celebrations"
        }
      ]
    }
  },
  {
    id: 'physical',
    title: 'Physical Education',
    icon: Activity,
    color: 'physical',
    topics: {
      S1: [
        {
          title: "Health and Fitness Basics",
          outcomes: [
            "Understand components of fitness",
            "Develop healthy lifestyle habits",
            "Learn basic exercise principles"
          ],
          content: "Physical education promotes health, fitness, and well-being through movement and exercise.\n\nComponents of fitness:\n• Cardiovascular endurance: heart and lung strength\n• Muscular strength: maximum force production\n• Muscular endurance: repeated muscle contractions\n• Flexibility: range of motion in joints\n• Body composition: ratio of fat to muscle\n\nBenefits of exercise:\n• Stronger heart and lungs\n• Improved muscle and bone strength\n• Better mental health\n• Increased energy levels\n• Better sleep quality\n• Disease prevention\n• Social interaction\n\nBasic exercise principles:\n• Frequency: how often\n• Intensity: how hard\n• Time: how long\n• Type: what kind\n• Progression: gradual increase\n• Rest and recovery"
        }
      ],
      S2: [
        {
          title: "Team Sports and Games",
          outcomes: [
            "Learn rules of common team sports",
            "Develop teamwork skills",
            "Practice fair play and sportsmanship"
          ],
          content: "Team sports teach cooperation, communication, and healthy competition.\n\nPopular team sports:\n• Football (soccer): 11 players, goal scoring\n• Basketball: 5 players, shooting hoops\n• Volleyball: 6 players, hitting over net\n• Netball: 7 players, shooting goals\n• Rugby: contact sport with oval ball\n• Cricket: batting and bowling game\n\nTeamwork skills:\n• Communication on the field\n• Supporting teammates\n• Sharing responsibilities\n• Trust and cooperation\n• Following strategies\n• Encouraging others\n\nSportsmanship values:\n• Respect for opponents\n• Following rules\n• Accepting decisions\n• Winning and losing gracefully\n• Fair play\n• Self-control\n• Effort and perseverance"
        }
      ],
      S3: [
        {
          title: "Individual Sports and Athletics",
          outcomes: [
            "Master individual sport techniques",
            "Understand track and field events",
            "Set personal fitness goals"
          ],
          content: "Individual sports focus on personal achievement and self-improvement.\n\nTrack events:\n• Sprints: 100m, 200m, 400m\n• Middle distance: 800m, 1500m\n• Long distance: 3000m, 5000m\n• Hurdles: obstacles to jump\n• Relays: team running events\n\nField events:\n• Jumping: long jump, high jump, triple jump\n• Throwing: shot put, discus, javelin\n• Combined: heptathlon, decathlon\n\nOther individual sports:\n• Swimming: different strokes and distances\n• Gymnastics: strength, flexibility, coordination\n• Tennis: racket sport with ball\n• Badminton: racket sport with shuttlecock\n• Table tennis: indoor racket sport\n\nTraining principles:\n• Specific training for each sport\n• Progressive overload\n• Recovery and rest\n• Technique before speed/power\n• Mental preparation"
        }
      ],
      S4: [
        {
          title: "Exercise Science and Sports Leadership",
          outcomes: [
            "Understand how the body responds to exercise",
            "Design training programs",
            "Develop leadership skills in sports"
          ],
          content: "Advanced physical education includes understanding exercise science and developing leadership skills.\n\nHow exercise affects the body:\n• Heart rate increases during exercise\n• Breathing becomes deeper and faster\n• Muscles warm up and become more flexible\n• Body temperature rises\n• Energy systems provide fuel\n• Recovery processes restore the body\n\nTraining program design:\n• Assess current fitness level\n• Set specific, measurable goals\n• Choose appropriate exercises\n• Plan progression over time\n• Include rest and recovery\n• Monitor and adjust program\n\nSports leadership roles:\n• Team captain: motivates and guides team\n• Coach: teaches skills and strategies\n• Referee/official: enforces rules fairly\n• Sports organizer: plans events\n• Fitness instructor: leads exercise sessions\n\nLeadership qualities:\n• Good communication\n• Fair decision-making\n• Problem-solving skills\n• Positive attitude\n• Knowledge of rules and safety\n• Ability to motivate others"
        }
      ]
    }
  },
  {
    id: 'ai',
    title: 'AI Prompting',
    icon: Brain,
    color: 'ai',
    topics: {
      S1: [
        {
          title: "Introduction to AI and Learning",
          outcomes: [
            "Understand what AI is and how it works",
            "Learn basic AI concepts",
            "Practice simple AI interactions"
          ],
          content: "Artificial Intelligence (AI) helps computers perform tasks that typically require human intelligence.\n\nWhat is AI?\n• Computer systems that can learn\n• Programs that can solve problems\n• Technology that can understand language\n• Systems that can recognize patterns\n• Tools that can make predictions\n\nTypes of AI:\n• Chatbots: for conversations\n• Image recognition: identifying objects\n• Voice assistants: understanding speech\n• Recommendation systems: suggesting content\n• Game AI: playing games\n\nHow AI learns:\n• From large amounts of data\n• By recognizing patterns\n• Through trial and error\n• By copying human behavior\n• By following rules and instructions\n\nAI in everyday life:\n• Search engines\n• Social media feeds\n• Online shopping recommendations\n• Navigation apps\n• Language translation"
        }
      ],
      S2: [
        {
          title: "Basic AI Prompting Techniques",
          outcomes: [
            "Write clear and specific prompts",
            "Understand how to communicate with AI",
            "Practice basic prompt structures"
          ],
          content: "Prompting is how we communicate with AI to get helpful responses.\n\nGood prompt characteristics:\n• Clear and specific\n• Complete sentences\n• Proper grammar and spelling\n• Include context when needed\n• Ask one thing at a time\n\nBasic prompt types:\n• Questions: 'What is photosynthesis?'\n• Instructions: 'Explain how plants make food'\n• Requests: 'Please summarize this chapter'\n• Examples: 'Give me 3 examples of renewable energy'\n\nPrompt structure:\n1. Context: What subject or topic\n2. Task: What you want the AI to do\n3. Format: How you want the answer\n4. Level: What grade level or complexity\n\nExample prompt:\n'I'm a Senior 2 biology student. Can you explain photosynthesis in simple terms with 3 main steps?'\n\nTips for better prompts:\n• Be polite and respectful\n• Check spelling before sending\n• Ask follow-up questions\n• Verify important information"
        }
      ],
      S3: [
        {
          title: "AI for Research and Study",
          outcomes: [
            "Use AI to assist with homework and projects",
            "Learn to verify AI-generated information",
            "Practice ethical AI use"
          ],
          content: "AI can be a powerful study tool when used correctly and ethically.\n\nUsing AI for research:\n• Getting topic overviews\n• Finding examples and explanations\n• Breaking down complex concepts\n• Creating study questions\n• Summarizing long texts\n• Generating practice problems\n\nSample research prompts:\n• 'Explain the causes of World War I in simple terms'\n• 'Give me 5 practice math problems about quadratic equations'\n• 'What are the main themes in this poem?'\n• 'Help me understand the water cycle step by step'\n\nVerifying AI information:\n• Check multiple sources\n• Look for official websites\n• Ask teachers or experts\n• Use textbooks and libraries\n• Be skeptical of unusual claims\n\nEthical AI use guidelines:\n• Don't copy AI answers directly\n• Use AI to understand, not replace learning\n• Always cite AI assistance\n• Don't use AI for exams without permission\n• Respect academic integrity rules\n• Learn the concepts, don't just get answers"
        }
      ],
      S4: [
        {
          title: "Advanced AI Applications and Digital Literacy",
          outcomes: [
            "Understand AI's role in various fields",
            "Develop critical thinking about AI",
            "Create effective prompting strategies"
          ],
          content: "Advanced AI skills include understanding limitations and using AI creatively and responsibly.\n\nAI in different fields:\n• Medicine: diagnosing diseases, drug discovery\n• Education: personalized learning, tutoring\n• Science: data analysis, research assistance\n• Art: generating images, music, stories\n• Business: automation, customer service\n• Environment: climate modeling, conservation\n\nAdvanced prompting strategies:\n• Role-playing: 'Act as a biology teacher and explain...'\n• Step-by-step: 'Break this down into 5 simple steps'\n• Comparison: 'Compare and contrast these two concepts'\n• Creative: 'Create a story that explains this concept'\n• Socratic: 'Ask me questions to help me understand this'\n\nAI limitations to understand:\n• Can make mistakes or 'hallucinate' false facts\n• May reflect biases in training data\n• Cannot replace human judgment\n• Limited by knowledge cutoff dates\n• Cannot browse internet in real-time\n• May not understand context perfectly\n\nCritical thinking with AI:\n• Question the source of information\n• Consider multiple perspectives\n• Verify important claims\n• Understand the difference between correlation and causation\n• Recognize when human expertise is needed\n• Maintain healthy skepticism"
        }
      ]
    }
  },
  {
    id: 'history',
    title: 'History',
    icon: BookOpen,
    color: 'history',
    topics: {
      S1: [
        {
          title: "Introduction to History",
          outcomes: [
            "Understand what history is and its importance",
            "Learn about historical sources",
            "Develop skills in historical thinking"
          ],
          content: "History is the study of past events and their impact on the present."
        }
      ],
      S2: [
        {
          title: "Early African Civilizations",
          outcomes: [
            "Learn about ancient African kingdoms",
            "Understand trade routes and economic systems"
          ],
          content: "Africa has a rich history of advanced civilizations and kingdoms."
        }
      ],
      S3: [
        {
          title: "Colonial Period in Africa",
          outcomes: [
            "Understand the impact of colonialism",
            "Learn about resistance movements"
          ],
          content: "European colonization profoundly impacted African societies."
        }
      ],
      S4: [
        {
          title: "Independence and Modern Africa",
          outcomes: [
            "Learn about independence movements",
            "Understand challenges of nation-building"
          ],
          content: "African countries gained independence through various means and faced new challenges."
        }
      ]
    }
  },
  {
    id: 'english',
    title: 'English Language',
    icon: MessageCircle,
    color: 'english',
    topics: {
      S1: [
        {
          title: "Reading and Comprehension",
          outcomes: [
            "Develop reading fluency",
            "Understand different text types"
          ],
          content: "Reading is fundamental to learning and communication."
        }
      ],
      S2: [
        {
          title: "Writing Skills",
          outcomes: [
            "Write for different purposes",
            "Use appropriate language and style"
          ],
          content: "Effective writing communicates ideas clearly and purposefully."
        }
      ],
      S3: [
        {
          title: "Speaking and Listening",
          outcomes: [
            "Communicate effectively in spoken English",
            "Listen actively and critically"
          ],
          content: "Oral communication skills are essential for academic and social success."
        }
      ],
      S4: [
        {
          title: "Literature and Language Study",
          outcomes: [
            "Analyze literary texts",
            "Understand literary devices"
          ],
          content: "Literature study develops critical thinking and cultural understanding."
        }
      ]
    }
  },
  {
    id: 'agriculture',
    title: 'Agriculture',
    icon: Wheat,
    color: 'agriculture',
    topics: {
      S1: [
        {
          title: "Introduction to Agriculture",
          outcomes: [
            "Understand the importance of agriculture",
            "Identify basic agricultural tools"
          ],
          content: "Agriculture is the practice of growing crops and raising animals for food, fiber, and other products."
        }
      ],
      S2: [
        {
          title: "Crop Production",
          outcomes: [
            "Learn about major crops in Uganda",
            "Understand crop growing requirements"
          ],
          content: "Successful crop production requires understanding plant needs and proper management."
        }
      ],
      S3: [
        {
          title: "Animal Husbandry",
          outcomes: [
            "Learn about livestock management",
            "Understand animal nutrition and health"
          ],
          content: "Animal husbandry involves caring for domestic animals for food, fiber, and other products."
        }
      ],
      S4: [
        {
          title: "Sustainable Agriculture",
          outcomes: [
            "Understand sustainable farming practices",
            "Learn about value addition"
          ],
          content: "Modern agriculture focuses on sustainability and business opportunities."
        }
      ]
    }
  }
];
